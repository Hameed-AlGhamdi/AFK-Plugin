package com.iihmd.aFKPlugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AFKManager {

    private final AFKPlugin plugin;
    private final Map<UUID, Long> afkCooldowns = new HashMap<>();
    private final Map<UUID, Boolean> afkStatus = new HashMap<>();
    private final Map<UUID, Long> lastMovement = new HashMap<>();

    public AFKManager(AFKPlugin plugin) {
        this.plugin = plugin;
        startAFKCheckTask();
    }

    public void toggleAFK(Player player) {
        UUID playerId = player.getUniqueId();
        if (isAFK(player)) {
            afkStatus.put(playerId, false);
            String noLongerAFKMessage = ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.no-longer-afk"));
            player.sendMessage(noLongerAFKMessage);
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.no-longer-afk-broadcast").replace("%player%", player.getName())));
        } else {
            afkStatus.put(playerId, true);
            String nowAFKMessage = ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.now-afk"));
            player.sendMessage(nowAFKMessage);
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.afk-broadcast").replace("%player%", player.getName())));
        }
    }

    public boolean isAFK(Player player) {
        return afkStatus.getOrDefault(player.getUniqueId(), false);
    }

    public void setLastMovement(Player player) {
        lastMovement.put(player.getUniqueId(), System.currentTimeMillis());
    }

    private void startAFKCheckTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    UUID playerId = player.getUniqueId();
                    if (!isAFK(player)) {
                        long lastMoveTime = lastMovement.getOrDefault(playerId, System.currentTimeMillis());
                        if (System.currentTimeMillis() - lastMoveTime > 180000) { // 3 minutes
                            toggleAFK(player);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20, 20);
    }

    public boolean canToggleAFK(Player player) {
        long lastToggleTime = afkCooldowns.getOrDefault(player.getUniqueId(), 0L);
        return System.currentTimeMillis() - lastToggleTime > 5000;
    }

    public void setAFKCooldown(Player player) {
        afkCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }
}
