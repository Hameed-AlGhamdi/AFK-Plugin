package com.iihmd.aFKPlugin;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class AFKPlugin extends JavaPlugin {

    private AFKManager afkManager;
    private FileConfiguration config;

    @Override
    public void onEnable() {
        this.saveDefaultConfig();
        config = this.getConfig();

        afkManager = new AFKManager(this);

        this.getCommand("afk").setExecutor(new AFKCommand(this));
        this.getServer().getPluginManager().registerEvents(new AFKListener(this), this);

        getLogger().info("SimpleAFK Plugin Enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SimpleAFK Plugin Disabled.");
    }

    public AFKManager getAfkManager() {
        return afkManager;
    }

    public FileConfiguration getPluginConfig() {
        return config;
    }

    public void reloadPluginConfig() {
        reloadConfig();
        config = getConfig();
    }
}
