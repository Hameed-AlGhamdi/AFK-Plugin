package com.iihmd.aFKPlugin;

import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.entity.Player;
import org.bukkit.entity.Monster;
import org.bukkit.event.player.PlayerInteractEvent;

public class AFKListener implements Listener {

    private final AFKPlugin plugin;

    public AFKListener(AFKPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        if (plugin.getAfkManager().isAFK(player)) {
            if (!event.getFrom().equals(event.getTo())) {
                // إذا كان اللاعب نفسه هو من يحاول الحركة
                if (isPlayerMovingByItself(event.getFrom(), event.getTo())) {
                    plugin.getAfkManager().toggleAFK(player); // إلغاء وضع AFK عند محاولة الحركة
                } else {
                    event.setCancelled(true); // إلغاء الحركة إذا تم محاولة التحريك من جهة خارجية
                }
            }
        } else {
            // إذا كان اللاعب يتحرك بشكل طبيعي، يتم إلغاء وضع AFK
            plugin.getAfkManager().setLastMovement(player);
        }
    }

    private boolean isPlayerMovingByItself(Location from, Location to) {
        return from.distanceSquared(to) < 0.01; // تحقق من أن الحركة صغيرة جداً, لتكون منطقية بأنها تشير إلى حركة اللاعب نفسه
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (event.getRightClicked() instanceof Player) {
            Player target = (Player) event.getRightClicked();
            if (plugin.getAfkManager().isAFK(target)) {
                event.setCancelled(true); // يمنع اللاعبين من التفاعل مع اللاعب في وضع AFK
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (plugin.getAfkManager().isAFK(player)) {
            event.setCancelled(true); // يمنع اللاعب AFK من التفاعل مع أي شيء
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player) {
            Player victim = (Player) event.getEntity();

            if (plugin.getAfkManager().isAFK(victim)) {
                // تحقق مما إذا كان الضرر ناتج عن لاعب أو وحش
                if (event.getDamager() instanceof Player || event.getDamager() instanceof Monster) {
                    event.setCancelled(true); // يمنع اللاعبين أو الوحوش من إحداث الضرر وتحريك اللاعب
                }

                // إعادة تعيين موقع الضحية إذا كانت في وضع AFK
                victim.teleport(victim.getLocation());
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();

            if (plugin.getAfkManager().isAFK(player)) {
                event.setCancelled(true); // يمنع اللاعب من التعرض لأي ضرر أثناء AFK

                // إعادة تعيين موقع اللاعب لمنعه من التحرك
                player.teleport(player.getLocation());
            }
        }
    }

    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        if (event.getTarget() instanceof Player) {
            Player playerTarget = (Player) event.getTarget();

            if (plugin.getAfkManager().isAFK(playerTarget)) {
                event.setCancelled(true); // يمنع الوحوش من استهداف اللاعب
            }
        }
    }

    @EventHandler
    public void onPlayerVelocity(PlayerVelocityEvent event) {
        Player player = event.getPlayer();

        if (plugin.getAfkManager().isAFK(player)) {
            event.setCancelled(true); // منع تغيير السرعة/الاندفاع للاعب في وضع AFK
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();

        if (plugin.getAfkManager().isAFK(player)) {
            event.setCancelled(true); // منع النقل التلقائي للاعب في وضع AFK
        }
    }
}