package com.iihmd.aFKPlugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AFKCommand implements CommandExecutor {

    private final AFKPlugin plugin;

    public AFKCommand(AFKPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;

        if (command.getName().equalsIgnoreCase("afk")) {
            if (!player.hasPermission("simple.afk.use")) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.no-permission")));
                return true;
            }

            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (player.hasPermission("simple.afk.admin")) {
                    plugin.reloadPluginConfig();
                    player.sendMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.reload-success")));
                } else {
                    player.sendMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.no-permission")));
                }
                return true;
            }

            if (plugin.getAfkManager().canToggleAFK(player)) {
                plugin.getAfkManager().toggleAFK(player);
                plugin.getAfkManager().setAFKCooldown(player);
            } else {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', plugin.getPluginConfig().getString("messages.afk-cooldown")));
            }
            return true;
        }

        return false;
    }
}
